﻿using AppProps;
using BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _3TierWeb
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        ProductBLL bll = new ProductBLL();
        protected void Page_Load(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void DisplayData()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\OneDrive\Documents\dbOfficeManagementSystem.mdf;Integrated Security=True;Connect Timeout=30");
            DataTable dt = new DataTable();
            SqlDataAdapter adapt = new SqlDataAdapter("select * from tblEmployee", conn);
            adapt.Fill(dt);
            GridView1.DataSource = dt;
            conn.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Product prod = new Product();
            prod.Id=int.Parse(txtId.Text);
            prod.Name=txtName.Text;
            prod.Description=txtDesc.Text;
            prod.Quantity=txtQuan.Text;
            ProductBLL obj = new ProductBLL();
            if (obj.AddProductBLL(prod))
            {
                lblMsg.Text = "Inserted Successfully";
                DisplayData();
            }
            else
            {
                lblMsg.Text = "Not Inserted Successfully";
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Product prod = new Product();
            prod.Id=int.Parse(txtId.Text);
            prod.Name=txtName.Text;
            prod.Description=txtDesc.Text;
            prod.Quantity=txtQuan.Text;
            ProductBLL obj = new ProductBLL();
            if (obj.UpdateProductBLL(prod))
            {
                lblMsg.Text = "Updated Successfully.";
                DisplayData();
            }
            else
            {
                lblMsg.Text = "Not Updated";
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Product prod = new Product();
            prod.Id=int.Parse(txtId.Text);
            ProductBLL obj = new ProductBLL();
            if (obj.DeleteProductBLL(prod))
            {
                lblMsg.Text = "Deleted Successfully.";
                DisplayData();
            }
            else
            {
                lblMsg.Text = "Data Not Deleted.";
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Product prod = new Product();
            prod.Id=int.Parse(txtId.Text);
            ProductBLL obj = new ProductBLL();
            DataTable dt = new DataTable();
            dt = obj.SearchProductBLL(prod);
            if (dt.Rows.Count > 1)
            {
                // dataGridView1.DataSource = dt;
                lblMsg.Text = "Something Went Wrong";
            }
            else
            {
                txtId.Text = dt.Rows[0]["prodId"].ToString();
                txtName.Text = dt.Rows[0]["prodName"].ToString();
                txtDesc.Text = dt.Rows[0]["prodDescription"].ToString();
                txtQuan.Text = dt.Rows[0]["prodQuantity"].ToString();
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("MaterWeb.aspx");
        }
    }
}