﻿using AppProps;
using BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _3TierWeb
{
    public partial class LoginForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            AppProps.User u = new AppProps.User();
            u.Name = txtUser.Text;
            u.Pass = txtPass.Text;
            UserBLL b = new UserBLL();
            DataTable dt = b.LoginUserBLL(u);
            if(dt!=null)
            {
                int accessLevel = dt.Rows[0][“userAccessLevel”].ToString();
                Session[“user”]= u.Name;
                Session[“user”]= u.AccessLevel;
                if (accessLevel == 0)
                    Response.Redirect(“AdminPage.aspx”);
                else if if (accessLevel == 1)
                        Response.Redirect(“HoDPage.aspx”);
                    else if if (accessLevel == 2)
                            Response.Redirect(“CoordinatorPage.aspx”);
                        else if if (accessLevel == 3)
                                Response.Redirect(“FacultyPage.aspx”);
                            else if if (accessLevel == 4)
                                    Response.Redirect(“StudentPage.aspx”);
            }
            else
            {
                Lbl.Text = “Login failed”;
            }
                

        }
    }
}