﻿using AppProps;
using BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _3TierWeb
{
    public partial class User : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            AppProps.User u = new AppProps.User();
            u.Id = int.Parse(txtID.Text);
            u.Name = txtName.Text;
            u.Pass = txtPass.Text;
            u.AccessLevel = int.Parse(DDLAccessLevel.SelectedItem.Value.ToString());
            u.ActiveStatus= int.Parse(DDLActiveStatus.SelectedItem.Value.ToString());
            if (!txtPass.Text.Equals(txtCnfrmPass.Text))
            {
                LabelError.Text = "Password is not same on both fields";
            }
            else
            {
                UserBLL obj = new UserBLL();
                if (obj.registerUserBLL(u))
                {
                    LabelError.Text = "User Saved";
                }
                else
                {
                    LabelError.Text = "User Not Saved";
                }
            }
            
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("LoginForm.aspx");
        }
    }
}