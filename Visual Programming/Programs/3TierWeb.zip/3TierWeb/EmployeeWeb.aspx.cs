﻿using AppProps;
using BusinessLogicLayer;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _3TierWeb
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void DisplayData()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\OneDrive\Documents\dbOfficeManagementSystem.mdf;Integrated Security=True;Connect Timeout=30");
            DataTable dt = new DataTable();
            SqlDataAdapter adapt = new SqlDataAdapter("select * from tblEmployee", conn);
            adapt.Fill(dt);
            GridView1.DataSource = dt;
            conn.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Id=int.Parse(txtId.Text);
            emp.Name=txtName.Text;
            emp.Cell=txtCell.Text;
            emp.Address=txtAddress.Text;
            EmployeeBLL obj = new EmployeeBLL();
            if (obj.AddEmployeeBLL(emp))
            {
                lblMsg.Text="Added Successfully.";
                DisplayData();
            }
            else
            {
                lblMsg.Text = "Data not added.";
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Id=int.Parse(txtId.Text);
            emp.Name=txtName.Text;
            emp.Cell=txtCell.Text;
            emp.Address=txtAddress.Text;
            EmployeeBLL obj = new EmployeeBLL();
            if (obj.UpdateEmployeeBLL(emp))
            {
                lblMsg.Text="Updated Successfully.";
                DisplayData();
            }
            else
            {
                lblMsg.Text = "Data not Updated.";
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Id=int.Parse(txtId.Text);
            EmployeeBLL obj = new EmployeeBLL();
            if (obj.DeleteEmployeeBLL(emp))
            {
                lblMsg.Text="Deleted Successfully.";
                DisplayData();
            }
            else
            {
                lblMsg.Text = "Data not Deleted.";
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Id=int.Parse(txtId.Text);
            EmployeeBLL obj = new EmployeeBLL();
            DataTable dt = new DataTable();
            dt = obj.SearchEmployeeBLL(emp);
            if (dt.Rows.Count > 1)
            {
                // dataGridView1.DataSource = dt;
                lblMsg.Text = "Something Went Wrong";
            }
            else
            {
                txtId.Text = dt.Rows[0]["empId"].ToString();
                txtName.Text = dt.Rows[0]["empName"].ToString();
                txtCell.Text = dt.Rows[0]["empCell"].ToString();
                txtAddress.Text = dt.Rows[0]["empAddress"].ToString();
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("MasterWeb.aspx");
        }
    }
}