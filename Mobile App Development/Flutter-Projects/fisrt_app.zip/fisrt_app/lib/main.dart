import 'package:flutter/material.dart';

void main() {
  runApp(
    const MaterialApp(
      title: 'Flutter Tutorial',
      home: TutorialHome(),
    ),
  );
}

class TutorialHome extends StatelessWidget {
  const TutorialHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const IconButton(
          icon: Icon(Icons.account_box_rounded),
          tooltip: 'Navigation menu',
          onPressed: null,
        ),
        title: const Text('Flutter App'),
        actions: const [
          IconButton(
            icon: Icon(Icons.access_alarm_rounded),
            tooltip: 'Search',
            onPressed: null,
          ),
        ],
      ),
      body: Center(
        child: SizedBox(
          child: Image.asset('assets/image1.png'),
        ),
      ),
      floatingActionButton: const FloatingActionButton(
        tooltip: 'Add',
        onPressed: null,
        backgroundColor: Colors.green,
        child: Icon(Icons.favorite),
      ),
    );
  }
}
