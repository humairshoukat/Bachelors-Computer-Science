package com.example.form_valid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
