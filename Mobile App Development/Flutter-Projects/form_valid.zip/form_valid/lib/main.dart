import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    const appTitle = 'Form Validation';
    return const MaterialApp(
      title: appTitle,
      home: Scaffold(
        body: SafeArea(child: CustomForm()),
      ),
    );
  }
}

class CustomForm extends StatefulWidget {
  const CustomForm({super.key});

  @override
  State<CustomForm> createState() => CustomFormState();
}

class CustomFormState extends State<CustomForm> {
  final _formkey = GlobalKey<FormState>();
  final _numberRegExp = RegExp(r'^[0-9]+$');

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formkey,
      child: Column(children: <Widget>[
        TextFormField(
          decoration: const InputDecoration(
            hintText: 'Enter your email',
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Enter some number'; //text
            } else if (!_numberRegExp.hasMatch(value)) {
              return 'Please enter a valid number';
            }
            return null;
          },
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16.0),
          child: ElevatedButton(
            onPressed: () {
              if (_formkey.currentState!.validate()) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('The input is valid')),
                );
              }
            },
            child: const Text('Submit'),
          ),
        )
      ]),
    );
  }
}

// class CustomForm extends StatefulWidget {
//   const CustomForm({Key? key}) : super(key: key);

//   @override
//   State<CustomForm> createState() => CustomFormState();
// }

// class CustomFormState extends State<CustomForm> {
//   bool passwordVisible = false;
//   bool ConfirmpasswordVisible = false;
//   bool is_checked = false;
//   final formData = GlobalKey<FormState>();
//   final emailController = TextEditingController();
//   final passwordController = TextEditingController();
//   final ConfirmpasswordController = TextEditingController();
//   final nameController = TextEditingController();
//   bool formSubmitted = false;

//   @override
//   void initState() {
//     super.initState();
//     passwordVisible = true;
//     ConfirmpasswordVisible = true;
//   }

//   bool arePasswordsMatching() {
//     return passwordController.text == ConfirmpasswordController.text;
//   }

//   bool isCheckboxChecked() {
//     return is_checked;
//   }

//   void showSnackBar(String message) {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text(message),
//         duration: const Duration(seconds: 2),
//       ),
//     );
//   }

//   bool validateConfirmPassword(String? value) {
//     if (value == null || value.isEmpty) {
//       return false;
//     }
//     if (value != passwordController.text) {
//       return false;
//     }
//     return true;
//   }

//   void signUp() {
//     if (formData.currentState!.validate()) {
//       setState(() {
//         formSubmitted = true;
//       });

//       if (!arePasswordsMatching()) {
//         showSnackBar("Passwords do not match");
//         return;
//       }

//       if (!isCheckboxChecked()) {
//         showSnackBar("Please agree to terms and privacy policy");
//         return;
//       }

//       showSnackBar("Sign up successful");
//     }
//   }

//   bool nameFieldFocused = false;
//   bool emailFieldFocused = false;
//   bool passwordFieldFocused = false;
//   bool confirmPasswordFieldFocused = false;

//   double getRelativeHeight(BuildContext context, double factor) {
//     return MediaQuery.of(context).size.height * factor;
//   }

//   double getRelativeWidth(BuildContext context, double factor) {
//     return MediaQuery.of(context).size.width * factor;
//   }

//   Color getColor(Set<MaterialState> states) {
//     return states.contains(MaterialState.selected) ? Colors.green : Colors.grey;
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.green,
//       ),
//       backgroundColor: Colors.white,
//       body: SafeArea(
//         child: Padding(
//           padding: EdgeInsets.symmetric(
//             horizontal: getRelativeWidth(context, 0.05),
//             vertical: getRelativeHeight(context, 0.01),
//           ),
//           child: Form(
//             autovalidateMode: formSubmitted
//                 ? AutovalidateMode.always
//                 : AutovalidateMode.disabled,
//             key: formData,
//             child: SingleChildScrollView(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 mainAxisAlignment: MainAxisAlignment.start,
//                 children: [
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.02),
//                   ),
//                   Text(
//                     'Sign up',
//                     style: TextStyle(
//                       fontSize: getRelativeHeight(context, 0.07),
//                       fontWeight: FontWeight.bold,
//                       color: Colors.green,
//                     ),
//                   ),
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.01),
//                   ),
//                   Text(
//                     'Please fill this to create your Account',
//                     textAlign: TextAlign.center,
//                     style: TextStyle(
//                       fontSize: getRelativeHeight(context, 0.021),
//                       fontFamily: '',
//                       color: Colors.black,
//                     ),
//                   ),
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.03),
//                   ),
//                   Text(
//                     'Name',
//                     style: TextStyle(
//                       color: Colors.green,
//                       fontSize: getRelativeHeight(context, 0.022),
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.01),
//                   ),
//                   TextFormField(
//                     controller: nameController,
//                     keyboardType: TextInputType.text,
//                     onChanged: (_) {
//                       setState(() {
//                         nameFieldFocused = true;
//                         formSubmitted = false;
//                       });
//                       formData.currentState!.validate();
//                     },
//                     validator: (value) {
//                       if (nameFieldFocused &&
//                           formSubmitted &&
//                           (value == null || value.isEmpty)) {
//                         return 'Please enter your name';
//                       }
//                       return null;
//                     },
//                     decoration: InputDecoration(
//                       hintText: 'Enter your Name',
//                       fillColor: Colors.grey,
//                       filled: true,
//                       prefixIcon: const Icon(
//                         Icons.person_2,
//                         color: Colors.green,
//                       ),
//                       enabledBorder: OutlineInputBorder(
//                         borderSide: BorderSide(
//                           color: Colors.grey.shade300,
//                           width: 2,
//                         ),
//                       ),
//                       errorBorder: const OutlineInputBorder(
//                         borderSide: BorderSide(
//                           color: Colors.red,
//                           width: 2,
//                         ),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderSide: const BorderSide(
//                           color: Colors.green,
//                           width: 2,
//                         ),
//                         borderRadius: BorderRadius.circular(
//                             getRelativeWidth(context, 0.04)),
//                       ),
//                     ),
//                   ),
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.01),
//                   ),
//                   Text(
//                     'Email',
//                     style: TextStyle(
//                       color: Colors.green,
//                       fontSize: getRelativeHeight(context, 0.022),
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.01),
//                   ),
//                   TextFormField(
//                     controller: emailController,
//                     keyboardType: TextInputType.text,
//                     onChanged: (_) {
//                       setState(() {
//                         passwordFieldFocused = true;
//                         formSubmitted = false;
//                       });
//                       formData.currentState!.validate();
//                     },
//                     validator: (value) {
//                       if (passwordFieldFocused &&
//                           formSubmitted &&
//                           (value == null || value.isEmpty)) {
//                         return 'Please enter your email';
//                       }
//                       return null;
//                     },
//                     decoration: InputDecoration(
//                       hintText: 'Enter your Email',
//                       fillColor: Colors.grey,
//                       filled: true,
//                       prefixIcon: const Icon(
//                         Icons.email_outlined,
//                         color: Colors.green,
//                       ),
//                       enabledBorder: OutlineInputBorder(
//                         borderSide: BorderSide(
//                           color: Colors.grey.shade300,
//                           width: 2,
//                         ),
//                       ),
//                       errorBorder: const OutlineInputBorder(
//                         borderSide: BorderSide(
//                           color: Colors.red,
//                           width: 2,
//                         ),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderSide: const BorderSide(
//                           color: Colors.green,
//                           width: 2,
//                         ),
//                         borderRadius: BorderRadius.circular(
//                             getRelativeWidth(context, 0.04)),
//                       ),
//                     ),
//                   ),
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.01),
//                   ),
//                   Text(
//                     'Password',
//                     style: TextStyle(
//                       color: Colors.green,
//                       fontSize: getRelativeHeight(context, 0.022),
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.01),
//                   ),
//                   TextFormField(
//                     controller: passwordController,
//                     obscureText: passwordVisible,
//                     keyboardType: TextInputType.text,
//                     onChanged: (_) {
//                       setState(() {
//                         passwordFieldFocused = true;
//                         formSubmitted = false;
//                       });
//                       formData.currentState!.validate();
//                     },
//                     validator: (value) {
//                       if (passwordFieldFocused &&
//                           formSubmitted &&
//                           (value == null || value.isEmpty)) {
//                         return 'Please enter your password';
//                       }
//                       return null;
//                     },
//                     decoration: InputDecoration(
//                       hintText: 'Enter Your Password',
//                       fillColor: Colors.grey,
//                       filled: true,
//                       enabledBorder: OutlineInputBorder(
//                         borderSide: BorderSide(
//                           color: Colors.grey.shade300,
//                           width: 2,
//                         ),
//                       ),
//                       errorBorder: const OutlineInputBorder(
//                         borderSide: BorderSide(
//                           color: Colors.red,
//                           width: 2,
//                         ),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderSide: const BorderSide(
//                           color: Colors.green,
//                           width: 2,
//                         ),
//                         borderRadius: BorderRadius.circular(
//                             getRelativeWidth(context, 0.04)),
//                       ),
//                       prefixIcon: const Icon(
//                         Icons.lock_open,
//                         color: Colors.green,
//                       ),
//                       suffixIcon: IconButton(
//                         icon: Icon(passwordVisible
//                             ? Icons.visibility
//                             : Icons.visibility_off),
//                         color: Colors.green,
//                         onPressed: () {
//                           setState(
//                             () {
//                               passwordVisible = !passwordVisible;
//                             },
//                           );
//                         },
//                       ),
//                     ),
//                   ),
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.01),
//                   ),
//                   Text(
//                     'Confirm Password',
//                     style: TextStyle(
//                       color: Colors.green,
//                       fontSize: getRelativeHeight(context, 0.022),
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.01),
//                   ),
//                   TextFormField(
//                     controller: ConfirmpasswordController,
//                     obscureText: passwordVisible,
//                     keyboardType: TextInputType.text,
//                     onChanged: (_) {
//                       setState(() {
//                         confirmPasswordFieldFocused = true;
//                         formSubmitted = false;
//                       });
//                       formData.currentState!.validate();
//                     },
//                     validator: (value) {
//                       if (confirmPasswordFieldFocused &&
//                           formSubmitted &&
//                           (value == null || value.isEmpty)) {
//                         if (arePasswordsMatching()) {
//                           return 'Password do not match';
//                         }
//                         return 'Please enter your confirm password';
//                       }
//                       return null;
//                     },
//                     decoration: InputDecoration(
//                       hintText: 'Confirm Password',
//                       fillColor: Colors.green,
//                       filled: true,
//                       enabledBorder: OutlineInputBorder(
//                         borderSide: BorderSide(
//                           color: Colors.grey.shade300,
//                           width: 2,
//                         ),
//                       ),
//                       errorBorder: const OutlineInputBorder(
//                         borderSide: BorderSide(
//                           color: Colors.red,
//                           width: 2,
//                         ),
//                       ),
//                       focusedBorder: OutlineInputBorder(
//                         borderSide: const BorderSide(
//                           color: Colors.green,
//                           width: 2,
//                         ),
//                         borderRadius: BorderRadius.circular(
//                             getRelativeWidth(context, 0.04)),
//                       ),
//                       prefixIcon: const Icon(
//                         Icons.lock_open,
//                         color: Colors.green,
//                       ),
//                       suffixIcon: IconButton(
//                         icon: Icon(ConfirmpasswordVisible
//                             ? Icons.visibility
//                             : Icons.visibility_off),
//                         color: Colors.green,
//                         onPressed: () {
//                           setState(
//                             () {
//                               ConfirmpasswordVisible = !ConfirmpasswordVisible;
//                             },
//                           );
//                         },
//                       ),
//                     ),
//                   ),
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.02),
//                   ),
//                   Row(
//                     children: [
//                       Checkbox(
//                         value: is_checked,
//                         fillColor: MaterialStateProperty.resolveWith(getColor),
//                         onChanged: (val) {
//                           setState(() {
//                             is_checked = val!;
//                           });
//                         },
//                       ),
//                       Text(
//                         'Agree to the terms of use and privacy policy',
//                         style: TextStyle(
//                           fontSize: getRelativeHeight(context, 0.016),
//                           color: Colors.black,
//                           //fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ],
//                   ),
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.03),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.symmetric(
//                       horizontal: getRelativeWidth(context, 0.015),
//                       vertical: getRelativeHeight(context, 0),
//                     ),
//                     child: ElevatedButton(
//                       onPressed: () {
//                         signUp();
//                       },
//                       child: null,
//                     ),
//                   ),
//                   SizedBox(
//                     height: getRelativeHeight(context, 0.05),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
