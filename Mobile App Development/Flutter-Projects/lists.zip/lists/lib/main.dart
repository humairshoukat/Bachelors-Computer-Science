import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'List View',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('List View'),
        ),
        body: ListView(
          children: const [
            ListTile(
              leading: Icon(Icons.star),
              title: Text('Item 1'),
              tileColor: Colors.red,
            ),
            Divider(), // Separator line
            ListTile(
              leading: Icon(Icons.star),
              title: Text('Item 1'),
              tileColor: Colors.deepPurple,
            ),
            Divider(), // Separator line
            ListTile(
              leading: Icon(Icons.star),
              title: Text('Item 1'),
              tileColor: Colors.orange,
            ),
            // const Divider(), // Separator line
            // Container(
            //   color: Colors.orange, // Background color for the third ListTile
            //   child: const ListTile(
            //     leading: Icon(Icons.star),
            //     title: Text('Item 3'),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}
