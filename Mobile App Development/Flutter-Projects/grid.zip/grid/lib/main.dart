import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Grid View",
      home: Scaffold(
        appBar: AppBar(
          title: const Text("Grid Example"),
        ),
        body: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          children: List.generate(6, (index) {
            return Padding(
                padding: const EdgeInsets.all(10),
                child: Container(
                  color: Colors.lightGreen,
                  child: const Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.star,
                        color: Colors.yellow,
                        size: 30,
                      ),
                      Text("Grid Item"),
                    ],
                  ),
                ));
          }),
        ),
      ),
    );
  }
}
