package com.example.grid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
