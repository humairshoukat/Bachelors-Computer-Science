package com.example.tab_controller

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
