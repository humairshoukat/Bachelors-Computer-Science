import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Image Gallery',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: GalleryPage(),
    );
  }
}

class GalleryPage extends StatelessWidget {
  final List<ImageInfo> images = [
    ImageInfo(
      imagePath: 'assets/image1.png',
      imageName: 'Coke',
      imageDescription: 'New latest coke cane with refreshing taste',
    ),
    ImageInfo(
      imagePath: 'assets/image2.png',
      imageName: 'DSLR',
      imageDescription: 'New DSLR with latest AI features',
    ),
    // Add more ImageInfo objects for additional images
  ];

  GalleryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Image Gallery'),
      ),
      body: ListView.builder(
        itemCount: images.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailsPage(
                    imageInfo: images[index],
                  ),
                ),
              );
            },
            child: Card(
              margin: EdgeInsets.all(8.0),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Image.asset(
                      images[index].imagePath,
                      height: 200, // Adjust the height as needed
                      width: 200,
                      fit: BoxFit.cover,
                    ),
                    SizedBox(height: 8),
                    Text(
                      images[index].imageName,
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class DetailsPage extends StatelessWidget {
  final ImageInfo imageInfo;

  const DetailsPage({super.key, required this.imageInfo});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Image Details'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              imageInfo.imagePath,
              height: 400, // Adjust the height as needed
              width: 400,
              fit: BoxFit.cover,
            ),
            const SizedBox(height: 16),
            Text(
              imageInfo.imageName,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              imageInfo.imageDescription,
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}

class ImageInfo {
  final String imagePath;
  final String imageName;
  final String imageDescription;

  ImageInfo({
    required this.imagePath,
    required this.imageName,
    required this.imageDescription,
  });
}


// class GalleryPage extends StatelessWidget {
//   final List<String> images = [
//     'assets/image1.png',
//     'assets/image2.png',
//     // Add more image paths as needed
//   ];

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Image Gallery'),
//       ),
//       body: ListView.builder(
//         itemCount: images.length,
//         itemBuilder: (context, index) {
//           return GestureDetector(
//             onTap: () {
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => DetailsPage(
//                     imageUrl: images[index],
//                     imageName:
//                         'Image ${index + 1}', // Replace with your image name logic
//                     imageDescription:
//                         'Description for Image ${index + 1}', // Replace with your image description logic
//                   ),
//                 ),
//               );
//             },
//             child: Card(
//               margin: const EdgeInsets.all(8.0),
//               child: Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     Image.asset(
//                       images[index],
//                       height: 200, // Adjust the height as needed
//                       width: 200,
//                       fit: BoxFit.cover,
//                     ),
//                     const SizedBox(height: 8),
//                     Text(
//                       'Image ${index + 1}',
//                       style: const TextStyle(
//                           fontSize: 18, fontWeight: FontWeight.bold),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }

// // class GalleryPage extends StatelessWidget {
// //   final List<String> images = [
// //     'assets/image1.png',
// //     'assets/image2.png',
// //     // Add more image paths as needed
// //   ];

// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text('Image Gallery'),
// //       ),
// //       body: GridView.builder(
// //         gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
// //           crossAxisCount: 2,
// //           crossAxisSpacing: 8.0,
// //           mainAxisSpacing: 8.0,
// //         ),
// //         itemCount: images.length,
// //         itemBuilder: (context, index) {
// //           return GestureDetector(
// //             onTap: () {
// //               Navigator.push(
// //                 context,
// //                 MaterialPageRoute(
// //                   builder: (context) => DetailsPage(
// //                     imageUrl: images[index],
// //                     imageName:
// //                         'Image ${index + 1}', // Replace with your image name logic
// //                     imageDescription:
// //                         'Description for Image ${index + 1}', // Replace with your image description logic
// //                   ),
// //                 ),
// //               );
// //             },
// //             // onTap: () {
// //             //   Navigator.push(
// //             //     context,
// //             //     MaterialPageRoute(
// //             //       builder: (context) => DetailsPage(imageUrl: images[index]),
// //             //     ),
// //             //   );
// //             // },
// //             child: Image.asset(images[index], fit: BoxFit.cover),
// //           );
// //         },
// //       ),
// //     );
// //   }
// // }

// class DetailsPage extends StatelessWidget {
//   final String imageUrl;
//   final String imageName;
//   final String imageDescription;

//   const DetailsPage({
//     super.key,
//     required this.imageUrl,
//     required this.imageName,
//     required this.imageDescription,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Image Details'),
//       ),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.center,
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Image.asset(
//               imageUrl,
//               height: 200, // Adjust the height as needed
//               width: 200,
//               fit: BoxFit.cover,
//             ),
//             const SizedBox(height: 16),
//             Text(
//               imageName,
//               style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
//             ),
//             const SizedBox(height: 8),
//             Text(
//               imageDescription,
//               style: const TextStyle(fontSize: 18),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// // class DetailsPage extends StatelessWidget {
// //   final String imageUrl;
// //   final String imageName; // Add image name
// //   final String imageDescription; // Add image description

// //   DetailsPage(
// //       {required this.imageUrl,
// //       this.imageName = '',
// //       this.imageDescription = ''});

// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text('Image Details'),
// //       ),
// //       body: Column(
// //         crossAxisAlignment: CrossAxisAlignment.center,
// //         mainAxisAlignment: MainAxisAlignment.center,
// //         children: [
// //           Image.asset(imageUrl),
// //           // SizedBox(height: 50),
// //           Text(
// //             'Name: $imageName',
// //             style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
// //           ),
// //           // SizedBox(height: 10),
// //           Text(
// //             'Description: $imageDescription',
// //             style: TextStyle(fontSize: 16),
// //           ),
// //         ],
// //       ),
// //     );
// //   }
// // }
