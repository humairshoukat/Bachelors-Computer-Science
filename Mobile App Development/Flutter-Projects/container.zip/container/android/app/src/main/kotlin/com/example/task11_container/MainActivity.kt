package com.example.task11_container

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
