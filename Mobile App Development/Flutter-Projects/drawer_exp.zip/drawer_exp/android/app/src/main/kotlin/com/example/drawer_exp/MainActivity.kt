package com.example.drawer_exp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
