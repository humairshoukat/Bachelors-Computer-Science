/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class SCal extends Cal{
    
    void Sin()
    {
        System.out.println("Sin Cal");
    }
    
    void Cos()
    {
        System.out.println("Cos Cal");
    }
    
    void Tan()
    {
        System.out.println("Tan Cal");
    }
    
}
