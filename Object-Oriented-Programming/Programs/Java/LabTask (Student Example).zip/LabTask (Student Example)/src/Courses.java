/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
public class Courses {
private int CourseCode;
private String CourseTitle;

Courses()
{
 CourseCode=0;
 CourseTitle="N/A";
}

Courses(int code, String title)
{
    CourseCode=code;
    CourseTitle=title;
}

public void setCourseCode(int code)
{
    CourseCode=code;
}

public int getCourseCode()
{
    return CourseCode;
}

public void setCourseTitle(String title)
{
    CourseTitle=title;
}

public String getCourseTitle()
{
    return CourseTitle;
}

void showCourse()
{
    System.out.println("Course Code: " +CourseCode);
    System.out.println("Course Title: " +CourseTitle);
}

}
