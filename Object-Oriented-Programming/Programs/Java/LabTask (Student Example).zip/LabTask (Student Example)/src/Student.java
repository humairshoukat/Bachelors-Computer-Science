/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
public class Student {
private int RollNo;
private String Name;
Courses [] Crs=new Courses[3];
Student()
{
 RollNo=0;
 Name="N/A";
}

Student(int rno, String nam)
{
    RollNo=rno;
    Name=nam;
}

public void setRollNo(int rno)
{
    RollNo=rno;
}

public int getRollNo()
{
    return RollNo;
}

public void setName(String nam)
{
    Name=nam;
}

public String getName()
{
    return Name;
}

void showStudent()
{
    System.out.println("Roll #: "+ RollNo);
    System.out.println("Name: "+ Name);
}

}
