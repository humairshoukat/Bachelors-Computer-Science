/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner input= new Scanner(System.in);
    
    System.out.print("Enter Number of Students: ");
    int n=input.nextInt();
    Student[] std=new Student[n];
    
    for(int i=0; i<n; i++)
    {
        std[i]=new Student();
        System.out.print("Enter Roll No of Student 0"+(i+1)+": ");
        int rollno=input.nextInt();
        std[i].setRollNo(rollno);
    
        System.out.print("Enter Name of Student 0"+(i+1)+": ");
        String name=input.next();
        std[i].setName(name);
        
        for(int j=0; j<3; j++)
        {
            std[i].Crs[j]=new Courses();
            System.out.print("Enter Course Code 0"+(j+1)+" of Student 0"+(i+1)+": ");
            int code=input.nextInt();
            std[i].Crs[j].setCourseCode(code);
        
            System.out.print("Enter Course Title 0"+(j+1)+" of Student 0"+(i+1)+": ");
            String title=input.next();
            std[i].Crs[j].setCourseTitle(title);
        }
    }
    
    System.out.println("********OUTPUT********");
    for(int i=0; i<n; i++)
    {
        System.out.println("Data of Student 0"+(i+1)+": ");
        std[i].showStudent();
        System.out.println("Courses of Student 0"+(i+1)+" is as follow: ");
        for(int j=0; j<3; j++)
        {
            std[i].Crs[j].showCourse();
        }
        System.out.println("");
    }
    
    }
    
}
